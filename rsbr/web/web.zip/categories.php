
    <section class="resume-section p-3 p-lg-5 d-flex justify-content-center" id="about">
      <div class="w-100">
        <div align="center" class=" subheading mb-5">Royal Success Book of Records crucially monitors the higher 
		Achievements in the following categories</div>

		<div id="rsbr_records_categories" class="container-fluid scrollbar">
		 <div class="row">
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Antique Collections</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		   
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			      <b>Arts and Crafts</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		   
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Architecture</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		   
		 </div>
		 <div class="row">
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Astrology</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		   
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Baby</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		   
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Vehicles</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		   
		 </div>
		 <div class="row">
		   
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Clothing</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		   
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Food and Drink</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		   
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Computers and Electronic Gadgets</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		</div><!--/.row -->
		
		<div class="row">
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Music and Entertainment</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		   
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Religion and Culture</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		   
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Sports and Games</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		 
		 </div>
		 
		 <div class="row">
		   
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Home and Furniture</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		 
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Celebrity</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		   
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Pets and Animals</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		   
		 </div>
		 
		  <div class="row">
		   
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Internet and Softwares</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		   
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Science and Technology</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		 
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Languages</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		   
		 </div>
		 
		  <div class="row">
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Collections</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		   
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Political</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Social Media</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		</div>
		
		<div class="row">
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Toys</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		   
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Education and Study</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		   
		   <div class="col-sm-4 mtop15p">
		     <!-- -->
		     <div class="list-group">
			   <div align="center" class="list-group-item">
			     <b>Exercise and Human Body</b>
			   </div>
			 </div>
			 <!-- -->
		   </div>
		 
		 </div>
		
		</div>
	
      </div>

    </section>
