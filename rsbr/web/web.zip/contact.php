<section class="resume-section p-3 p-lg-5 d-flex align-items-center" id="skills">
      <div class="w-100">
        <h3 class="mb-5">Contact us</h3>
		<p>To get an adjudication service you can call us at <b><i>+91-9160111369, +91-9052111369</i></b>. 
		You can also email us at <b><i>royalsuccessbookofrecords@gmail.com</i></b> </p>
		<div class="subheading mb-3">OUR HEAD OFFICE</div>
		<div>
		<p>
		
		<div class="social-icons mb-3">
		   <a href="#">
            <i class="fa fa-university"></i>
          </a>
		   <b>#Address</b>
		 </div>
		 <div class="social-icons mb-3">
		   <a href="#">
            <i class="fa fa-envelope"></i>
          </a>
		    <b>royalsuccessbookofrecords@gmail.com</b>
		 </div>
		 
		 <div class="social-icons mb-3">
		   <a href="#">
            <i class="fa fa-phone"></i>
          </a>
		    <b>+91-9160111369, +91-9052111369</b>
		 </div>
		
		</p>
		</div>
       
	   <div align="right" class="social-icons mb-5">
          <a href="#">
            <i class="fab fa-linkedin-in"></i>
          </a>
          <a href="#">
            <i class="fab fa-github"></i>
          </a>
          <a href="#">
            <i class="fab fa-twitter"></i>
          </a>
          <a href="#">
            <i class="fab fa-facebook-f"></i>
          </a>
        </div>
		
	   </div>
    </section>
    