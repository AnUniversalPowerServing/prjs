<?php
$val="http://localhost/prjs/rsbr/webapp/uploads/customers/1/1570456022712.pdf";

echo $fileName;
?>