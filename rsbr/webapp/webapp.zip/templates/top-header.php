<script type="text/javascript">
$(document).ready(function(){
 if($(window).width()<=768){
  sideWrapperToggle();
 }
 alert_display_success('S001','#');
});
function sideWrapperToggle(){
if($("#wrapper").hasClass('toggled')) { 
 $("#wrapper").removeClass('toggled'); // hides SideMenu
 // $("#page-content-wrapper").css("position","absolute");
}
else { 
 $("#wrapper").addClass("toggled");  // adds SideMenu
// $("#page-content-wrapper").css("position","fixed");
 // setTimeout(function(){ $("html").addClass("stop-vertificalScroll"); },400);
}
}
</script> 
<style>
@media (min-width: 768px){ #topMenu { float: right!important; } }

@font-face { font-family:glarious;src:url('fonts/glarious.otf'); }
@font-face { font-family:longdoosi-regular;src:url('fonts/longdoosi-regular.ttf'); }

.fs22p { font-size:22px; }

.mtop5p { margin-top:5px; }
.mtop15p { margin-top:15px; }
.mtop50p { margin-top:50px; }

.mbot5p { margin-bottom:5px; }
.mbot20p { margin-bottom:20px; }
.mbot50p { margin-bottom:50px; }

.font-white { color:#fff; }
.lh35p { line-height:35px; }

hr { border-bottom:2px solid #ccc; }
hr.tomato { border-bottom:2px solid tomato; }
hr.dodgerBlue { border-bottom:2px solid dodgerBlue; }
hr.black { border-bottom:2px solid black; }
hr.white { border-bottom:2px solid white; }

.btn-blue-o { background-color:#fff;border:2px solid dodgerblue;color:dodgerblue;font-weight:bold; }
.btn-green-o { background-color:#fff;border:2px solid mediumSeaGreen;color:mediumSeaGreen;font-weight:bold; }
.btn-tomato-o { background-color:#fff;border:2px solid tomato;color:tomato;font-weight:bold; }
.btn-orange-o { background-color:#fff;border:2px solid orange;color:orange;font-weight:bold; }
.btn-rsbr-o { background-color:#fff;border:2px solid #a02cd6;color:#a02cd6;font-weight:bold; }

.btn-rsbr2-o { background-color:#fff;border:1px solid #6d049e;color:#6d049e;font-weight:bold; }

.btn-rsbr3-o { background-color:#fff;border:1px solid #0e2551;color:#0e2551;font-weight:bold; }
.btn-rsbr3-o:hover { background-color:#0e2551;border:1px solid #0e2551;color:#fff; }

.btn-rsbr3 { background-color:#0e2551;border:1px solid #0e2551;color:#fff;font-weight:bold; }
.btn-rsbr3:hover { background-color:#fff;border:1px solid #0e2551;color:#0e2551; }

.btn-rsbr2 { background-color:#6d049e;color:#fff;border:1px solid #6d049e; }
.btn-rsbr2:hover { background-color:#a02cd6;color:#fff;border:1px solid #a02cd6; }


</style>

<nav class="navbar navbar-default" 
style="position:sticky;border:0px;border-radius:0px;background-color:#f7f7f7;margin-bottom:-10px;">

		  <div align="center" class="container-fluid">
			<div class="navbar-header">
			  <a class="navbar-brand" href="#" style="cursor:pointer;color:#0e2551;" onclick="javascript:sideWrapperToggle();">
			    <span class="glyphicon glyphicon-align-justify"></span>
			  </a>
			  <span><img src="images/logo.png" style="width:110px;height:110px;"/></span>
			</div>
		
			<div id="topMenu" style="margin-top:2%;">
			<form class="navbar-form navbar-left">
			  <?php
  			    if(isset($_SESSION["USER_ACCOUNT_ID"])) { 
			    if($_SESSION["USER_ACCOUNT_ID"]=='ADMINISTRATOR') { 
			  ?>
			   <div class="form-group">
			     <!-- -->
<style>
ul.dropdown-menu>li>a { color:#0e2551; }
.btn-default.active.focus, .btn-default.active:focus, .btn-default.active:hover, 
.btn-default:active.focus, .btn-default:active:focus, .btn-default:active:hover, 
.open>.dropdown-toggle.btn-default.focus, .open>.dropdown-toggle.btn-default:focus, 
.open>.dropdown-toggle.btn-default:hover {
    color: #fff;
    background-color: #0e2551;
    border-color: #0e2551;
}
</style>
				 <!-- -->
			  </div>
			  <div class="form-group">
			    <a href="#" data-toggle="modal" data-target="#messageBalance">
			      <button class="btn btn-default btn-rsbr3-o form-control">View Message Balance</button>
				</a>
			  </div>
			  
			  <div class="form-group">
			    <button class="btn btn-default btn-rsbr3-o form-control">logout</button>
			  </div>
			  
			  <?php } else if($_SESSION["USER_ACCOUNT_ID"]=='CUSTOMER') { ?>
			  <div class="form-group">
			    <button class="btn btn-default btn-rsbr3-o form-control"></button>
			  </div>
			  <?php } else { ?>
			  <div class="form-group">
			    <button class="btn btn-default btn-rsbr3-o form-control">Customer Login / Register</button>
			  </div>
			  <?php } } ?>
              <div class="form-group">
			    <button class="btn btn-default btn-rsbr3 form-control">Download Application</button>
			  </div>
			  
			</div>
			
		  </div>
	  </nav>

<!-- Modal ::: Start -->
<div id="messageBalance" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header" style="background-color:#0e2551;color:#fff;">
        <button type="button" class="close" data-dismiss="modal" style="color:#fff;">&times;</button>
        <h4 class="modal-title"><b>View Message Balance</b></h4>
      </div>
      <div class="modal-body">
      <!-- -->
	  <div class="container-fluid">
	   <div class="row">
	    <div align="center" class="col-md-12 col-sm-12 col-xs-12">
	    <!-- -->
		<h3>1000 Messages&nbsp;&nbsp;&nbsp;<a href="#"><span style="font-size:16px;"><b><u>SMS Recharge?</u></b></span></a></h3>
		<!-- -->
	    </div><!--/.col-md-6 -->
	   </div><!--/.row -->
	  </div><!--/.container-fluid -->
	  <!-- -->
      </div>
    </div>

  </div>
</div>
<!-- Modal :::End -->