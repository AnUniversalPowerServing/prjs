<style>
.home-media-div-img { width:100%;height:250px;padding:0px; }
.home-media-img { width:100%;height:250px; }
.home-media-img-desc { color:#777; }
.home-media-div { border:1px solid mediumSeaGreen; }
.home-media-title { font-family:longdoosi-regular;color:tomato; }
</style>
<div class="container-fluid"  style="height:auto;margin-bottom:50px;">

<div class="row">

 <div class="col-md-12 col-sm-12 col-xs-12">
   <h2 class="home-media-title">
    What's happening at Royal Success Book of Records?<hr class="tomato"/>
   </h2>
 </div>

</div><!--/.row -->
<div class="row">

  <div class="col-md-4 col-sm-4 col-xs-12">
    
	<div class="list-group">
	<div class="list-group-item home-media-div">
	
		<div class="list-group">
		  <div class="list-group-item home-media-div-img">
			<img src="https://cdn.pixabay.com/photo/2018/01/14/23/12/nature-3082832_960_720.jpg" 
			class="home-media-img"/>
		  </div><!--/.list-group-item -->
		</div><!--/.list-group -->
		
		<div align="justify" class="home-media-img-desc">
		Royal Success Book of Records  registered with Royal Success Book of Records, 
		make your login here. If not registered, please Register.
		</div>
		
		<div align="right">
		 <button class="btn btn-xs btn-default btn-green-o"><b>Know more</b></button>
		</div>
	
	</div><!--/.list-group-item -->
	</div><!--/.list-group -->
	
	
  </div><!--/.col-md-4 col-sm-4 col-xs-12 -->
  
  
  <div class="col-md-4 col-sm-4 col-xs-12">
    
	<div class="list-group">
	<div class="list-group-item home-media-div">
	
		<div class="list-group">
		  <div class="list-group-item home-media-div-img">
			<img src="https://cdn.pixabay.com/photo/2018/01/14/23/12/nature-3082832_960_720.jpg" 
			class="home-media-img"/>
		  </div><!--/.list-group-item -->
		</div><!--/.list-group -->
		
		<div align="justify" class="home-media-img-desc">
		Royal Success Book of Records  registered with Royal Success Book of Records, 
		make your login here. If not registered, please Register.
		</div>
		
		<div align="right">
		 <button class="btn btn-xs btn-default btn-green-o"><b>Know more</b></button>
		</div>
	
	</div><!--/.list-group-item -->
	</div><!--/.list-group -->
	
	
  </div><!--/.col-md-4 col-sm-4 col-xs-12 -->
  
  
  <div class="col-md-4 col-sm-4 col-xs-12">
    
	<div class="list-group">
	<div class="list-group-item home-media-div">
	
		<div class="list-group">
		  <div class="list-group-item home-media-div-img">
			<img src="https://cdn.pixabay.com/photo/2018/01/14/23/12/nature-3082832_960_720.jpg" 
			class="home-media-img"/>
		  </div><!--/.list-group-item -->
		</div><!--/.list-group -->
		
		<div align="justify" class="home-media-img-desc">
		Royal Success Book of Records  registered with Royal Success Book of Records, 
		make your login here. If not registered, please Register.
		</div>
		
		<div align="right">
		 <button class="btn btn-xs btn-default btn-green-o"><b>Know more</b></button>
		</div>
	
	</div><!--/.list-group-item -->
	</div><!--/.list-group -->
	
	
  </div><!--/.col-md-4 col-sm-4 col-xs-12 -->
  
</div><!--/.row -->
<div class="row">
  <div align="center" class="col-md-12 col-sm-12 col-xs-12">
    <button class="btn btn-default btn-tomato-o"><b>Know more</b></button>
  </div>
</div><!--/.row -->

</div><!-- container-fluid -->