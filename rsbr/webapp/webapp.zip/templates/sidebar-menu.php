<div id="sidebar-wrapper" style="background-color:#6d049e;">
	  <ul class="sidebar-nav">
        <li style="background-color:#6d049e;"><!-- background-color:tomato; -->
	       <a href="index.php" style="color:#fff;"><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;<span><b>Home</b></span></a>
        </li>
        <li style="background-color:#6d049e;"><!-- background-color:dodgerBlue; -->
	       <a href="about-us.php" style="color:#fff;">
		     <i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;<span><b>About Us</b></span>
		   </a>
        </li>	
		<li style="background-color:#6d049e;"><!-- background-color:#f73e7d; -->
	       <a href="what-logo-mean.php" style="color:#fff;">
		     <i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;
			 <span><b>What logo Mean?</b></span>
		   </a>
        </li>	
		<li style="background-color:#6d049e;"><!-- background-color:tomato; -->
	       <a href="#" style="color:#fff;">
		     <i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;
			 <span><b>Media</b></span>
			 <i class="fa fa-2x fa-angle-double-down pull-right" style="padding-top:8px;padding-right:8px;" aria-hidden="true"></i>
		  </a>
        </li>	
		<li style="background-color:#6d049e;"><!-- background-color:mediumSeaGreen; -->
	       <a href="#" style="color:#fff;">
		     <i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;
			 <span><b>Record</b></span>
			 <i class="fa fa-2x fa-angle-double-down pull-right" style="padding-top:8px;padding-right:8px;" aria-hidden="true"></i>
		  </a>
        </li>	
		<li style="background-color:#6d049e;"><!-- background-color:tomato; -->
	       <a href="#" style="color:#fff;">
		     <i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;
			 <span><b>Our Events</b></span>
		   </a>
        </li>
		<li style="background-color:#6d049e;"><!-- background-color:#f73e7d; -->
	       <a href="#" style="color:#fff;">
		     <i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;
			 <span><b>Our Panel Board</b></span>
		   </a>
        </li>	
		<li style="background-color:#6d049e;"><!-- background-color:#a02cd6; -->
	       <a href="#" style="color:#fff;">
		     <i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;
			 <span><b>Our Gallery</b></span>
		   </a>
        </li>
		<li style="background-color:#6d049e;"><!-- background-color:tomato; -->
	       <a href="#" style="color:#fff;">
		     <i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;
			 <span><b>Find Categories</b></span>
		   </a>
        </li>
		<li style="background-color:#6d049e;"><!-- background-color:mediumSeaGreen; -->
	       <a href="#" style="color:#fff;">
		     <i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;
			 <span><b>Frequently Asked Questions</b></span>
		   </a>
        </li>
		<li style="background-color:#6d049e;"><!-- background-color:slateBlue; -->
	       <a href="#" style="color:#fff;">
		     <i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;
			 <span><b>Careers</b></span>
		   </a>
        </li>
		<li style="background-color:#6d049e;"><!-- background-color:#f73e7d; -->
	       <a href="#" style="color:#fff;">
		     <i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;
			 <span><b>RSBR Store</b></span>
		   </a>
        </li>
		<li style="background-color:#6d049e;"><!-- background-color:mediumSeaGreen; -->
	       <a href="#" style="color:#fff;">
		     <i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;
			 <span><b>Advertise / Be a Sponsor</b></span>
		   </a>
        </li>
		<li style="background-color:#6d049e;"><!-- background-color:slateBlue; -->
	       <a href="#" style="color:#fff;">
		     <i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;
			 <span><b>Contact Us</b></span>
		   </a>
        </li>
		<li style="background-color:#6d049e;"><!-- background-color:dodgerBlue; -->
	       <a href="termsAndConditions.php" style="color:#fff;">
		     <i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;
			 <span><b>Terms and Conditions</b></span>
		   </a>
        </li>
		<li style="background-color:#6d049e;"><!-- background-color:tomato; -->
	       <a href="privacypolicy.php" style="color:#fff;">
		     <i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;
			 <span><b>Privacy Policy</b></span>
		   </a>
        </li>
        <!-- -->
		
		<!-- -->
       </ul>
	</div>
	