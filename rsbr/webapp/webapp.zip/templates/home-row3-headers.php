<div class="container-fluid"  style="height:auto;margin-bottom:50px;">

<div class="row">

<div class="col-md-6 col-sm-6 col-xs-12 home-item-bg3">
 
	 <div>
	  <h2 align="center" class="home-item-title">
		Royal Success Book of Records logo<hr/>
	  </h2>
	 </div><!--/div -->
	 <div align="center" class="home-item-title-desc">
	  Know the importance of Royal Success Book of Records logo and how it is designed by our team here.
	 </div><!--/div -->
	 <div align="center" class="col-md-12 col-sm-12 col-xs-12 mtop15p mbot20p">
	   <button class="btn btn-default btn-purple1-o"><b>Let's Go !</b></button>
	 </div><!--/div -->

 
</div><!--/.col-md-6 .col-sm-6 .col-xs-6 -->

<div class="col-md-6 col-sm-6 col-xs-12 home-item-bg4">

 <div>
  <h2 align="center" class="home-item-title">
   Our Panel Board<hr/>
  </h2>
 </div><!--/div -->
 <div align="center" class="home-item-title-desc">
 Know what is our panel board and how it executes. And who are the memebers and their responsibilities.
 </div><!--/div -->
 <div align="center" class="col-md-12 col-sm-12 col-xs-12 mtop15p mbot20p">
   <button class="btn btn-default btn-tomato-o"><b>Visit our Panel Board</b></button>
 </div><!--/div -->
 
</div><!--/.col-md-6 .col-sm-6 .col-xs-6 -->

</div><!--/.row -->


</div><!-- container-fluid -->