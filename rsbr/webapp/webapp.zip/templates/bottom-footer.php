<div class="container-fluid" style="margin-top:15px;background-color:#eee;">
<div class="row" style="margin-top:30px;margin-bottom:50px;">

<div align="center" class="col-md-6 col-sm-6 col-xs-12">
 <div style="margin-top:15px;margin-bottom:15px;text-transform-uppercase;font-family:longdoosi-regular;">
   <h5 style="font-size:28px;">About RSBR</h5>
 </div>
 
 <div align="center" class="col-md-6 col-sm-6 col-xs-12">
	<div style="font-size:16px;">
	  <div style="margin-top:5%;">About us</div>
	  <div style="margin-top:5%;">What logo mean?</div>
	  <div style="margin-top:5%;">Our Panel Board</div>
	  <div style="margin-top:5%;">Our Events</div>
	  <div style="margin-top:5%;">Our Gallery</div>
	  <div style="margin-top:5%;">Careers</div>  
	</div>
 </div>
 
 <div align="center" class="col-md-6 col-sm-6 col-xs-12">
    <div style="font-size:16px;">
      <div style="margin-top:5%;">Advertise /Be a Sponsor</div>
	  <div style="margin-top:5%;">Media</div>
	  <div style="margin-top:5%;">Contact Us</div>
	  <div style="margin-top:5%;">Terms and Conditions</div>
	  <div style="margin-top:5%;">Privacy Policy</div>
	  <div style="margin-top:5%;">Licensing</div>
	</div>
 </div>
 
</div><!--/.col-md-12 col-sm-12 col-xs-12 -->

<div align="center" class="col-md-6 col-sm-6 col-xs-12">

 <div style="margin-top:15px;margin-bottom:15px;text-transform-uppercase;font-family:longdoosi-regular;">
   <h5 style="font-size:28px;">Record Topics</h5>
 </div>
 
 <div align="center" class="col-md-6 col-sm-6 col-xs-12">
 <!-- -->
 <div style="font-size:16px;">
  <div style="margin-top:5%;">Find Categories</div>
  <div style="margin-top:5%;">Record Policies</div>
  <div style="margin-top:5%;">Record Breaking types</div>
  <div style="margin-top:5%;">RSBR Store</div>
  <div style="margin-top:5%;">Frequently Asked Questions</div>
  <div style="margin-top:5%;">Buy Record Books</div>
 </div>
 <!-- -->
 </div>
 
 <div align="center" class="col-md-6 col-sm-6 col-xs-12">
 <!-- -->
 <div style="font-size:16px;">
  <div style="margin-top:5%;">Apply to set a Record</div>
  <div style="margin-top:5%;">Invite a Judge</div>
  <div style="margin-top:5%;">What makes a RSBR Title?</div>
  <div style="margin-top:5%;">How to set / Break a Record</div>
  <div style="margin-top:5%;">Reasons for Application Rejection</div>
 </div>
 <!-- -->
 </div>
 
</div><!--/.col-md-12 col-sm-12 col-xs-12 -->


</div><!--/.row -->
</div><!--/.container-fluid -->
<div class="container-fluid" style="background-color:#fff;">
<div class="row" style="margin-top:30px;margin-bottom:30px;">
<div align="center" class="col-md-12 col-sm-12 col-xs-12">
<img src="images/anups-logo.jpg" style="width:250px;height:auto;"/>
</div><!--/.col-md-12 col-sm-12 col-xs-12 -->
</div><!--/.row -->
</div><!--/.container-fluid -->