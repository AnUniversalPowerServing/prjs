<style>
.home-record-div-img { width:100%;height:250px;padding:0px; }
.home-record-img { width:100%;height:250px; }
.home-record-img-desc { color:#777; }
.home-record-div { border:1px solid mediumSeaGreen; }
.home-record-title { font-family: longdoosi-regular; }

.home-record-ach-div-tomato { background-color:tomato; }
.home-record-ach-div-mediumSeaGreen { background-color:mediumSeaGreen; }
.home-record-ach-div-slateBlue { background-color:slateBlue; }
.home-record-ach-div-blue { background-color:dodgerBlue; }
.home-record-ach-img { width:200px;height:200px;border-radius:50%; }
</style>
<div class="container-fluid"  style="height:auto;margin-bottom:50px;">
 <div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
    <h2 class="home-record-title">
      See the Latest Records Achievement<hr class="black"/>
    </h2>
  </div><!--/.col-md-6 .col-sm-6 .col-xs-12 -->
 </div><!--/.row -->
 <div id="latestRecordAchievements"></div>

 <div class="row">
  <div align="center" class="col-md-12 col-sm-12 col-xs-12">
    <button class="btn btn-default btn-tomato-o"><b>View Recent Records</b></button>
  </div>
</div><!--/.row -->
 
</div><!-- container-fluid -->