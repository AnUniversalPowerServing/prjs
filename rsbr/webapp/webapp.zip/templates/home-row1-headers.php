<style>
.home-item-bg1 { background-color:mediumSeaGreen;color:#fff;min-height:340px; }
.home-item-bg2 { background-color:dodgerBlue;color:#fff;min-height:340px; }
.home-item-bg5 { background-color:tomato;color:#fff;min-height:320px; }
.home-item-bg6 { background-color:orange;color:#fff;min-height:320px; }

.home-item-bg3 { background-color:#a02cd6;color:#fff;min-height:260px; }
.home-item-bg4 { background-color:tomato;color:#fff;min-height:260px; }

.home-item-title { font-family:longdoosi-regular;letter-spacing:2px; }
.home-item-title-desc { font-family:arial;font-size:18px;letter-spacing:2px; }
</style>
<div class="container-fluid" style="height:auto;margin-bottom:50px;">

<div class="row">

<div class="col-md-6 col-sm-6 col-xs-12 home-item-bg1">
 
	 <div>
	  <h2 align="center" class="home-item-title">
	   How Royal Success Book of Records works?<hr/>
	  </h2>
	 </div><!--/div -->
	 <div align="center" class="home-item-title-desc">
	  Here you can find the process how Royal Success Book of Records works about record-breaking and 
	  the Royal Success Book of Records applications process, as well for our website and other products.
	 </div><!--/div -->
	 <div align="center" class="col-md-12 col-sm-12 col-xs-12 mtop15p mbot20p">
	   <button class="btn btn-default btn-green-o"><b>Watch Video</b></button>
	 </div><!--/div -->

 
</div><!--/.col-md-6 .col-sm-6 .col-xs-6 -->

<div class="col-md-6 col-sm-6 col-xs-12 home-item-bg2">

 <div>
  <h2 align="center" class="home-item-title">
   Find Categories where you can apply to Break a Record<hr/>
  </h2>
 </div><!--/div -->
 <div align="center" class="home-item-title-desc">
 Royal Success Book of Records crucially monitors the higher Achievements in the following categories
 </div><!--/div -->
 <div align="center" class="col-md-12 col-sm-12 col-xs-12 mtop15p mbot20p">
   <button class="btn btn-default btn-blue-o"><b>Know Categories</b></button>
 </div><!--/div -->
 
</div><!--/.col-md-6 .col-sm-6 .col-xs-6 -->

</div><!--/.row -->

</div><!--/.container-fluid -->